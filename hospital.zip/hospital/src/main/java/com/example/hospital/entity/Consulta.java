package com.example.hospital.entity;

import jakarta.persistence.*;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "consulta")
public class Consulta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer idConsulta;

    @Column(nullable = false)
    private LocalDateTime fecha; // Usa LocalDateTime para fecha y hora

    @Column(nullable = false)
    private String motivo;

    @Column(columnDefinition = "TEXT")
    private String diagnostico;

    // FK: id_paciente
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_paciente", nullable = false)
    @JsonIgnoreProperties("consultas")
    private Paciente paciente;

    // FK: id_doctor
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_doctor", nullable = false)
    private Doctor doctor;

    // Relación inversa con Receta (1 a 1)
    @OneToOne(mappedBy = "consulta", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("consulta")
    private Receta receta;
}